library(stringr)

#  Get file locations, file names and the eventual reponse file names.
labs_folder <- "~/ownCloud/Internal/IDS/Curriculum/Current Release Versions/Internal Working Files (doc & ppt)/1_Binder v2.0/3_Labs v2.0/"

lab_file_locations <- list.files(labs_folder, pattern = "^lab[1-9]+[a-z].Rmd", recursive = TRUE, full.names = TRUE)

lab_file_names <- str_extract(lab_file_locations, "lab[1-9]+[a-z].Rmd")

response_file_names <- gsub("(^lab[1-9][a-z])(.Rmd)", "\\1_response\\2", lab_file_names) 

# Loop through labs to create response sheets
for (i in seq_along(lab_file_locations)) {
  
  # Read in the regular lines from the .Rmd
  lab_lines <- readLines(lab_file_locations[i], warn = FALSE)
  
  # Find identifiers for the content
  minus_signs <- grep("---", lab_lines)
  equal_signs <- grep("===", lab_lines)
  slide_titles <- equal_signs - 1
  spaces <- slide_titles - 1
  asterisks <- grep("\\*\\*", lab_lines)
  
  # Change directions
  lab_lines[asterisks[1]] <- "Directions: Record your responses to the lab questions in the spaces provided."
  
  # Create the response header and text
  response_header <- lab_lines[minus_signs[1]:minus_signs[2]]
  response_text <- lab_lines[sort(c(equal_signs, slide_titles, spaces, asterisks))]
  response <- c(response_header, response_text)
  response <- gsub("^\\s+", "", response)
  response <- gsub("`r ", "`", response)
  
  # Write the response files
  response_dest_file <- paste0("~/Dropbox/IDS Curriculum Design/ids_labs/extras/responses/rmd/", response_file_names[i])
  writeLines(response, con = response_dest_file)
  rmarkdown::render(response_dest_file, output_dir = "~/Dropbox/IDS Curriculum Design/ids_labs/extras/responses/docx/")
}
